package com.example.cardlink.interfaces

interface LinkContract {
    fun methodToPassMyData(linkedin:String, github:String, facebook:String, twitter:String, website:String)
}